import token

import mysql.connector
import hashlib

from dataclasses import dataclass, asdict
from flask import jsonify
from time import time



class UserDAO:

    def connectBBDD(self):
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database="Tapatapp"
        )
        return connection
    def getUserByToken(self, token):
        con=self.connectBBDD()
        cursor=con.cursor(dictionary=True)
        query = "SELECT * FROM User WHERE token = %s"
        cursor.execute(query, (token,))
        user = cursor.fetchone()
        cursor.close()
        con.close()
        return user
    def login(self, identifier, password):
        # conexio a la base de dades
        con=self.connectBBDD()
        cursor=con.cursor(dictionary=True)
        query = """
        SELECT * FROM User WHERE (username = %s OR email = %s) AND password = %s
    """    
        cursor.execute(query, (identifier, identifier, password))
        user = cursor.fetchone()
        if user:
            token = self.setTokenUser(user['username'])
            user['token'] = token
        cursor.close()
        con.close()
        # Query per a validar usuari i contrasenya
        
        # Si validacio ok, generar token i actualitzar usuari a la base de dades
            # Si torna 1 registre User ok
            # Si no none 
        # Tancar connexio
        return user
    
    def setTokenUser(self, username):
        # conexio a la base de dades
        con=self.connectBBDD()
        cursor = con.cursor(dictionary=True)
        # Query per a generar token i actualitzar usuari a la base de dades
        token = self.getHash(username)
        query = "UPDATE User SET token = '" + token + "' WHERE username = '" + username + "'"
        cursor.execute(query)
        con.commit()
        # Tancar connexio
        cursor.close()
        con.close()
        return token


    def getHash(self, username):
        milliseconds = str(time() * 1000)
        data = username + milliseconds
        hash_object = hashlib.sha256(data.encode('utf-8'))
        return hash_object.hexdigest()
    
class childDao:
    def getChilds(self,username):
        
        return "TO-DO"
    
    def connectBBDD(self):
        # Usamos la misma conexión que UserDAO
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database="Tapatapp"
        )
        return connection

    def getTapsByToken(self, token):
        con = self.connectBBDD()
        cursor = con.cursor(dictionary=True)
        query = """
            SELECT t.* FROM Tap t
            JOIN Child c ON t.child_id = c.id  -- Antes tenías id_child
            JOIN RelationUserChild ruc ON c.id = ruc.child_id
            JOIN User u ON ruc.user_id = u.id
            WHERE u.token = %s
        """
        cursor.execute(query, (token,))
        taps = cursor.fetchall()
        cursor.close()
        con.close()
        return taps
 
dao = UserDAO()

u = dao.getUserByToken("ff1e48b02218f2b8186ac61958578c5add68ec1ae5f6bf7622b6ba28e4e7248c")
print(u)

